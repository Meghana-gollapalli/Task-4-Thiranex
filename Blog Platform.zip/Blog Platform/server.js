const express = require('express');
const cors = require('cors');

const app = express();

app.use(cors());
app.use(express.json());

let posts = [];

app.post('/add', (req, res) => {
    posts.push(req.body);
    res.send("Post Added");
});

app.get('/posts', (req, res) => {
    res.json(posts);
});

app.listen(5000, () => {
    console.log("Server Started");
});